#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);

IZIN=$(curl -sS https://raw.githubusercontent.com/windrase/izinsc/main/ip | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
    echo "IZIN DI TERIMA!!"
else
    clear
    figlet "Akses Di Tolak" | lolcat
    exit 0
fi
clear

# WARNA
BR='\e[94;1m'
Suffix='\e[0m'

# Update dan Install dependensi
apt update && apt upgrade -y
apt install python3 python3-pip sqlite3 -y
pip3 install -r requirements.txt
pip install pillow speedtest-cli aiohttp paramiko

# Input Data
clear
echo "INSTALL BOT CREATE SSH via TELEGRAM"
read -e -p "[*] Input Your Id Telegram :" admin
read -e -p "[*] Input Your bot Telegram :" token
read -e -p "[*] Input username Telegram :" user

# Simpan data untuk bot python
cat > /media/cybervpn/var.txt << END
ADMIN="$admin"
BOT_TOKEN="$token"
DOMAIN="$(cat /etc/xray/domain)"
DNS="$(cat /root/nsdomain)"
PUB="7fbd1f8aa0abfe15a7903e837f78aba39cf61d36f183bd604daa2fe4ef3b7b59"
OWN="$user"
SALDO="999999"
END

# FIX: Simpan data untuk script notifikasi (VLESS/VMESS limit)
mkdir -p /etc/bot
echo "#bot# $token $admin" > /etc/bot/.bot.db

clear
echo "Done"
echo "API KEY TOKEN : $token"
echo "ID            : $admin"

# Setup Service
cat > /usr/bin/nenen << END
#!/bin/bash
cd /media/
python3 -m cybervpn
END
chmod 777 /usr/bin/nenen

cat > /etc/systemd/system/cybervpn.service << END
[Unit]
Description=Simple CyberVPN
After=network.target

[Service]
WorkingDirectory=/root
ExecStart=/usr/bin/nenen
Restart=always

[Install]
WantedBy=multi-user.target
END

systemctl daemon-reload
systemctl start cybervpn
systemctl enable cybervpn

echo "Bot Berhasil Diinstall"